clear all; close all;

%path = "./pi4_c1-10/";
%path = "./npi2.5_c1-10/";
path = "./p0_c1-10/";
%path = "./otherway_flat/";

cone_params_f = load(strcat(path, "cone_params.mat"));
cone_params = cone_params_f.cone_params;

% Given image points, camera intrinsic params, relative position and
% orientation between camera and projector, and plane parameters, calculate
% cone params
image_p_f = readmatrix("data.csv");
image_p = image_p_f(:,2:end);
figure(1);
axis equal;
scatter(image_p(2,:), image_p(1,:));
xlim([0, 640]);
xlim([0, 480]);

% just use the old W because no time
W_f = load(strcat(path, "W.mat"));
W = W_f.W;

% use the old R and T as well
R_f = load(strcat(path, "R.mat"));
R = R_f.R;
T_f = load(strcat(path, "T.mat"));
T = T_f.T;

plane_params_f = load(strcat(path, "plane_params.mat"));
plane_params = plane_params_f.plane_params;

a_plane = plane_params(1,1);
b_plane = plane_params(2,1);
c_plane = plane_params(3,1);
d_plane = plane_params(4,1);

fsx = W(1,1);
fsy = W(2,2);
c0 = W(1,3);
r0 = W(2,3);

% parametric plane equation for z
func_z = @(x, y) -(a_plane*x + b_plane*y + d_plane)/c_plane;
% column and row for solving 
func_c = @(x, y) fsx*(x/func_z(x, y)) + c0;
func_r = @(x, y) fsy*(y/func_z(x, y)) + r0;

% set up a matrix to solve for 3d points given 2d point
points_3d = [];
for i=1:size(image_p, 2)
    c = image_p(1,i);
    r = image_p(2,i);
    
    row1 = [a_plane*(c-c0) + fsx*c_plane, b_plane*(c-c0), d_plane*(c-c0)];
    row2 = [a_plane*(r-r0), b_plane*(r-r0) + fsy*c_plane, d_plane*(r-r0)];
    A = [row1;row2];
    sol = null(A);
    sol = sol/sol(3,1);
    sol(3,1) = func_z(sol(1,1), sol(2,1));
    points_3d = [points_3d, sol];
end
figure(2);
scatter3(points_3d(1,:), points_3d(2,:), points_3d(3,:));
hold on;

% Given 3D points, find the equation of the cone from projector that
% produces them
% equation of a cone given a vertex and a guiding curve
% find equation of 3D ellipse (intersection of plane and ellipse) as
% guiding curve
func_row = @(x,y,z) [x^2, y^2, z^2, x*y, y*z, x*z];
choose_ind = randsample(size(points_3d,2),6);
choose_points = points_3d(:,choose_ind);
A = [];
for i=1:size(choose_points,2)
    % transform points from left coordinate frame to right
    p3d_right = R*choose_points(:,i) - transpose(R)*T;
    A = [A;func_row(p3d_right(1,1),p3d_right(2,1),p3d_right(3,1))];
end
% find coefficients of cone
ecp = null(A);
% derive actual cone parameters from results
% estimated cone_params willa ctually include an extra rotation term!!
ecp_reduced = ecp/ecp(1,1);
% est_cone_params = [1/sqrt(ecp_reduced(1,1));
%     1/sqrt(ecp_reduced(2,1));
%     1/sqrt(-1*ecp_reduced(3,1));
%     ecp_reduced(6,1)];
est_cone_params = [1/sqrt(ecp_reduced(1,1));
    1/sqrt(ecp_reduced(2,1));
    1/sqrt(-1*ecp_reduced(3,1))];

% calculate error from original cone using sum of squared diff
disp("Target cone: ");
disp(cone_params);
disp("Estimated cone: ");
disp(est_cone_params);
ssd_error = sum((est_cone_params - cone_params).^2);
disp("Cone parameter calibration error: ");
disp(ssd_error);

% For reconstruction, intersect a ray from the camera with the cone
% Challenge: there will always be two intersection points
%   1. only try to reconstruct points on the "left" half of the ellipse?
%   2. Can we assume the closest intersection is correct for left points
%   and furthest intersection for right points?
% Can you determine the normal of a surface from the coefficients of an
% ellipse?

% 3d reconstruction attempts complete. Grab the leftmost and rightmost few
% points
% Getting a good 3D reconstruction from a cone is very difficult. Lines
% intersect with the cone often.
% Solution: sort 2d points by column index. Solve only the first solution
% for the left and only the second solution for the right
% This is only works because there is no y  translational offset or x
% rotational offset between the camera and projector frames.
%   What's the more general way to do this?
image_p_sorted = transpose(sortrows(transpose(image_p), 1));
left_sample = image_p_sorted(:,1:5);
right_sample = image_p_sorted(:,end-4:end);

% Derive unit vector of 3D line from camera ray
% need either focal length or sx, sy
left_inter = [];
for i=1:size(left_sample, 2)
    % get 3d point sitting on the image plane
    % image_p already has 1 for some reason
    p3d = inv(W)*left_sample(:,i);
    p3d = R*p3d;
    % get unit vector
    u_p3d = p3d/norm(p3d);
    % get intersect between line and cone
    %line_cone(u_p3d, [0;0;0], est_cone_params);
    intersects = line_cone(u_p3d, R*-1*T, cone_params, false);
    % complex solutions eliminated
    left_inter = [left_inter, transpose(R)*intersects+T];
end
zlim([0,20]);
axis equal;
scatter3(left_inter(1,:), left_inter(2,:), left_inter(3,:), 'green', 'o', 'filled');

% Derive unit vector of 3D line from camera ray
% need either focal length or sx, sy
right_inter = [];
for i=1:size(right_sample, 2)
    % get 3d point sitting on the image plane
    % image_p already has 1 for some reason
    p3d = inv(W)*right_sample(:,i);
    p3d = R*p3d;
    % get unit vector
    u_p3d = p3d/norm(p3d);
    % get intersect between line and cone
    %line_cone(u_p3d, [0;0;0], est_cone_params);
    intersects = line_cone(u_p3d, R*-1*T, cone_params, true);
    % complex solutions eliminated
    right_inter = [right_inter, transpose(R)*intersects+T];
end
zlim([0,20]);
axis equal;
scatter3(right_inter(1,:), right_inter(2,:), right_inter(3,:), 'green', 'o', 'filled');