function [intersects] = line_cone(u_line, p_line, cone_params, outer)
    a = u_line(1,1);
    b = u_line(2,1);
    c = u_line(3,1);
    
    x0 = p_line(1,1);
    y0 = p_line(2,1);
    z0 = p_line(3,1);
    
    e = cone_params(1,1);
    f = cone_params(2,1);
    g = cone_params(3,1);
    
    q_a = a^2/e^2 + b^2/f^2 - c^2/g^2;
    q_b = 2*a*x0/e^2 + 2*b*y0/f^2 - 2*c*z0/g^2;
    q_c = x0^2/e^2 + y0^2/f^2 - z0^2/g^2;
    
    % quadratic formula for roots
    disc = (q_b^2 - 4*q_a*q_c)^0.5;
    t1 = (-1*q_b + disc)/(2*q_a);
    t2 = (-1*q_b - disc)/(2*q_a);
    
    if outer == true && isreal(t1) && t1 > 0
        intersects = [x0 + a*t1;
            y0 + b*t1;
            z0 + c*t1];
    else if outer == false && isreal(t2) && t2 > 0
        intersects = [x0 + a*t2;
            y0 + b*t2;
            z0 + c*t2];
    end
end