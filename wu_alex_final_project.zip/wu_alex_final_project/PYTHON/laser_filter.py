import numpy as np
import cv2
import time

class LaserFilter:
    """
    Take an image
    filter for red color
    perform sharpening filter
    correct coordinate system of image
    return detected coordinates of laser
    """
    def __init__(self):
        pass

    def get_coord(self, frame):
        # apply red filter
        result = self.red_filter(frame)
        # find centroid
        centroid = self.bitwise_centroid(result)
        if centroid is None:
            return None
        # convert to image coords
        return self.correct_coords(centroid)

    def red_filter(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # Color threshold of red in HSV
        lower_red = np.array([0, 0, 140])
        upper_red = np.array([40, 255, 255])
        # preparing the mask to overlay
        mask = cv2.inRange(hsv, lower_red, upper_red)
        result = cv2.bitwise_and(frame, frame, mask=mask)
        return result

    def bitwise_centroid(self, frame):
        centroid = np.array([0, 0]).transpose()
        count = 0
        for row in range(frame.shape[0]):
            for col in range(frame.shape[1]):
                if frame[row][col].any() > 0:
                    centroid[0] = centroid[0] + row
                    centroid[1] = centroid[1] + col
                    count = count + 1

        if count == 0:
            return None
        return centroid/count

    def correct_coords(self, centroid):
        # convert row/column coordinates into image coordinates
        # return frame.shape[0]
        return np.array([frame.shape[0] - centroid[0], centroid[1]]).transpose()

if __name__ == "__main__":
    filter = LaserFilter()
    # Set up videocap stream
    cap = cv2.VideoCapture(1)

    c_count = 0
    centroids = np.zeros((2, 1))
    while c_count < 60:
        _, frame = cap.read()
        centroid = filter.get_coord(frame)

        if centroid is not None:
            c_curr = np.empty((2, 1))
            c_curr[0, 0] = centroid[0]
            c_curr[1, 0] = centroid[1]
            centroids = np.hstack((centroids, c_curr))
            c_count = c_count + 1

        print(c_count)
        #cv2.imshow('frame', frame)
        #cv2.waitKey(0)

    np.savetxt("data.csv", centroids, delimiter=",")