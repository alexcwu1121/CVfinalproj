import serial
import keyboard
import time

class HardwareInterface():
    def __init__(self):
        # current angle of base
        self.angle = 0
        self.initSerial()

    def initSerial(self):
        # Establish serial port and baud rate
        self.ard = serial.Serial('COM3', 9600)
        if (self.ard.isOpen() == False):
            self.ard.open()

    def read_angle(self):
        """
        Waits until signal is sent back from Arduino, indicating a task has finished
        :return:
        """
        line = self.ard.readline()
        self.angle = float(line[0:4])

    def deploy_task(self, task):
        """
        Just send a single byte identifier of a task in utf8
        :param task:
        :return:
        """
        self.ard.write(task.encode())
        pass

    def run(self):
        """
        Listen to user input and either send or receive
        :param is_sim:
        :return:
        """
        while True:
            if keyboard.is_pressed('b'):
                self.deploy_task('b')
            elif keyboard.is_pressed('p'):
                self.deploy_task('p')
            elif keyboard.is_pressed('s'):
                self.deploy_task('s')
            elif keyboard.is_pressed('l'):
                self.deploy_task('l')
                self.read_angle()
            elif keyboard.is_pressed('r'):
                self.deploy_task('r')
                self.read_angle()

if __name__ == "__main__":
    hi = HardwareInterface()
    hi.run()