function [F] = probe_line(x, theta, center, plane_point, plane_norm)
    u = x - center(1:2,1);
    u = u/norm(u);
    F = u(2,1) - u(1,1)*tan(theta);
end