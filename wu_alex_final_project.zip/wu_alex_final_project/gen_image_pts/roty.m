function [R] = roty(ang)
    R = [cos(ang), 0, sin(ang);
        0, 1, 0;
        -1*sin(ang), 0, cos(ang)];
end