function [] = plot_calib_plane(plane_points)
    patch(plane_points(1,:),plane_points(2,:),plane_points(3,:),'o');
    alpha(0.3);
end