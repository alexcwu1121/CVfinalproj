function [intersects] = line_cone(u_line, p_line, cone_params)
    
end