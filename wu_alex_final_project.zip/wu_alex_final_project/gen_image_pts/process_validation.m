clear all; close all;
% Validation of active stereo calibration mathematics using a cone
% projector
% 1. Assume a calibration object with an ellipse is visible from the camera
% image
% 2. Assume the calibration object is a circular cone
% 3. Assume the relative positions and orientations of the camera to the
% projector are already known
% 4. Assume the intrinsic parameters of the camera are already known

% Objective: given the position and orientation of a calibration object and
% the camera image of a projected ellipse, derive the equation of the 3D
% cone projection object

% Transformation from left to right camera frame expressed in the world
% frame such that pr = R*(pl - T)
R = roty(pi/12);
%R = eye(3);
T = [2;0;0];

% Set the projector cone parameters, just to be solved later
a_p = 1;
c_p = 10;

% position of right camera center in left coordinate frame
center_l = [0;0;0];
center_r = [2;0;0];

% Assume the camera frame coincides with the world frame
figure(1);
plot3([center_l(1,1)],[center_l(2,1)],[center_l(3,1)], 'o');
hold on;
plot3([center_r(1,1)],[center_r(2,1)],[center_r(3,1)], 'o');
xlabel("x");
ylabel("y");
zlabel("z");
axis equal;
legend(["Left center","Right center"]);

% rotation of calibration plane object
%R_calib = roty(pi/4);
R_calib = roty(-pi/2.5);
%R_calib = roty(0);
% distance from origin to calib plane. just for testing
dist = 10;

% plot calibration plane object
% rotation of calibration plane object
calib_plane_points = R_calib*[5,-5,-5,5;
    5,5,-5,-5;
    0,0,0,0]+[0,0,0,0;0,0,0,0;1,1,1,1]*dist;
plot_calib_plane(calib_plane_points);

cone_params = [a_p; a_p; c_p];
plane_params = get_plane_params(calib_plane_points);
% find intersection of projector centerline with object plane
[center_proj,~] = line_plane_intersection(R'*[0;0;1], [2;0;0], plane_params(1:3,1), calib_plane_points(:,1));
[center_cam,~] = line_plane_intersection([0;0;1], [0;0;0], plane_params(1:3,1), calib_plane_points(:,1));
% find intersection of lines along cone and calibration object
intersections = [];
for theta=0:pi/20:2*pi
    sol = fsolve(@(x)cone_plane_probe(x, cone_params, plane_params, theta, center_proj, calib_plane_points(:,1), plane_params(1:3,1)), [1;1]);
    % solve for z component of plane
    a = plane_params(1,1);
    b = plane_params(2,1);
    c = plane_params(3,1);
    d = plane_params(4,1);
    sol = sol + center_proj(1:2,1);
    z_comp = -1*(a*sol(1,1) + b*sol(2,1) + d)/c;
    intersections = [intersections, [sol;z_comp]];
    line([center_r(1,1), sol(1,1)],[center_r(2,1), sol(2,1)],[center_r(3,1), z_comp]);
end
line([center_r(1,1), center_proj(1,1)],[center_r(2,1), center_proj(2,1)],[center_r(3,1), center_proj(3,1)]);
line([center_l(1,1), center_cam(1,1)],[center_l(2,1), center_cam(2,1)],[center_l(3,1), center_cam(3,1)]);
plot3(intersections(1,:),intersections(2,:),intersections(3,:), 'o');

% % rotate a vector around center axis of cone and find intersections with
% % plane
% % original line unit vector of cone
% cone_axis = R'*[0;0;1];
% % rotate a vector around center axis of cone and find intersections with
% % plane
% % original line unit vector of cone
% %probe_unit_vector = rotx((c_p/a_p)^-0.5)*cone_axis;
% probe_unit_vector = rotx(atan((c_p^2/a_p^2)^-0.5))*cone_axis;
% intersections = [];
% for theta=0:pi/20:2*pi
%     % rotation about cone axis
%     R_theta = axang2rotm([cone_axis', theta]);
%     [intersect,~] = line_plane_intersection(R_theta*probe_unit_vector, [2;0;0], plane_params(1:3,1), calib_plane_points(:,1));
%     intersections = [intersections, intersect];
%     line([center_r(1,1), intersect(1,1)],[center_r(2,1), intersect(2,1)],[center_r(3,1), intersect(3,1)]);
% end
% % plot centerlines and all intersections
% line([center_r(1,1), center_proj(1,1)],[center_r(2,1), center_proj(2,1)],[center_r(3,1), center_proj(3,1)]);
% line([center_l(1,1), center_cam(1,1)],[center_l(2,1), center_cam(2,1)],[center_l(3,1), center_cam(3,1)]);
% plot3(intersections(1,:),intersections(2,:),intersections(3,:), 'o');