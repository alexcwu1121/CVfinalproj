function [plane_params] = get_plane_params(plane_points)
    dv21 = plane_points(:,2) - plane_points(:,1);
    dv31 = plane_points(:,3) - plane_points(:,1);
    u = cross(dv21, dv31);
    u = u/norm(u);
    dz = plane_points(:,1)'*u;
    plane_params = [u;-1*dz];
end