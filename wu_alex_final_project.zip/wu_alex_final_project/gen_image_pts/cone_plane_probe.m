function [F] = cone_plane_probe(x, cone_params, plane_params, theta, center, plane_point, plane_norm)
    F(1) = cone_plane(x, cone_params, plane_params);
    F(2) = probe_line(x, theta, center, plane_point, plane_norm);
end