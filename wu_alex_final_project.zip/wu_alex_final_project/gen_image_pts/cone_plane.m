function [F] = cone_plane(x, cone_params, plane_params)
    % eq plane: ax + by + cz + d = 0
    % eq cone: x^2/e^2 + y^2/f^2 -z^2/g^2 = 0
    a = plane_params(1,1);
    b = plane_params(2,1);
    c = plane_params(3,1);
    d = plane_params(4,1);
    
    e = cone_params(1,1);
    f = cone_params(2,1);
    g = cone_params(3,1);
    
%     F = (1/e-a^2/(c^2*g))*x(1,1)^2 + (1/f-b^2/(c^2*g))*x(2,1)^2 -...
%         (2*a*b)/(c^2*g)*x(1,1)*x(2,1) - (2*a*d/(c^2*g))*x(1,1) - ...
%         (2*b*d/(c^2*g))*x(2,1) - d^2/(c^2*g);
    F = x(1,1)^2/e^2 + x(2,1)^2/f^2 -((a*x(1,1) + b*x(2,1) + d)/c)^2/g^2;
end