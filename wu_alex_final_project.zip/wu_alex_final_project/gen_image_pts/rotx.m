function [R] = rotx(ang)
    R = [1, 0, 0;
        0, cos(ang), -1*sin(ang);
        0, sin(ang), cos(ang)];
end