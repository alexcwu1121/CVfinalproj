function [R] = rot2D(theta)
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];
end