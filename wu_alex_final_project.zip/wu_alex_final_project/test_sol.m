clear all; close all;

syms a b c d e f x y z
A = [a, d/2, f/2;
    d/2,b,e/2;
    f/2,e/2,c];
v = [x;y;z];

disp(transpose(v)*A);